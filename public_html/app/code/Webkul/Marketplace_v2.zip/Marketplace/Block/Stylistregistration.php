<?php

namespace Webkul\Marketplace\Block;

class Stylistregistration extends \Magento\Framework\View\Element\Template
{
	public function __construct(\Magento\Framework\View\Element\Template\Context $context)
	{
		parent::__construct($context);
	}


	public function getFormAction()
	{
	       // companymodule is given in routes.xml
	       // controller_name is folder name inside controller folder
	       // action is php file name inside above controller_name folder

	   return '/stylist/seller/stylistregistration';
	}
}
