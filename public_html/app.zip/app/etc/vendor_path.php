<?php
/**
 * Path to Composer vendor directory
 */
return './vendor';
