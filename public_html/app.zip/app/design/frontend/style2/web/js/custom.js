require(['jquery', 'tinyslider'], function ($) {
  $(document).ready(function () {
    // ======= Reviews Slider Home Page
    var reviewSlides = $('.reviews-slideshow .review-slide').length;
    if (reviewSlides > 0) {
      var slider = tns({
        container: '.reviews-slideshow',
        items: 1,
        mouseDrag: true,
        loop: true,
        responsive: {
          0: {
            items: 1,
            nav: true,
            controls: false,
          },
          640: {
            nav: false,
            controls: true,
          },
        },
      });
    }

    // ======= Mobile Menu
    $('.nav-toggle').on('click', function () {
      $('.navigation-holder').addClass('opened-menu');
    });
    $('.close-mobile-menu-button').on('click', function () {
      $(this).parents('.navigation-holder').removeClass('opened-menu');
    });

    // ======= Slideshow Stylist Page
    var worksSlides = $(
      '.wk-mp-profile-works-slideshow .wk-mp-profile-works-slide'
    ).length;
    if (worksSlides > 0) {
      var sliderWorks = tns({
        container: '.wk-mp-profile-works-slideshow',
        mouseDrag: true,
        controls: true,
        responsive: {
          0: {
            items: 2,
            nav: false,
            controls: false,
          },
          640: {
            controls: true,
          },
          768: {
            edgePadding: 170,
          },
          1150: {
            edgePadding: 100,
            items: 4,
          },
        },
      });
    }

    var expertiseSlides = $(
      '.wk-mp-profile-expertise-slideshow .wk-mp-profile-expertise-slide'
    ).length;
    if (expertiseSlides > 0) {
      var sliderWorks = tns({
        container: '.wk-mp-profile-expertise-slideshow',
        nav: false,
        mouseDrag: true,
        responsive: {
          0: {
            items: 1,
            edgePadding: 90,
            gutter: 20,
            controls: false,
          },
          480: {
            items: 2,
            edgePadding: 70,
          },
          640: {
            items: 3,
            controls: true,
          },
          768: {
            items: 4,
            edgePadding: 50,
          },
          880: {
            items: 5,
            edgePadding: 0,
          },
          1024: {
            items: 6,
          },
          1200: {
            gutter: 30,
          },
        },
      });
    }

    var adviceSlides = $('.advice-list li').length;
    if (adviceSlides > 0) {
      var sliderAdvice = tns({
        container: '.advice-list',
        mouseDrag: true,
        navPosition: true,
        controls: false,
        nav: true,
        responsive: {
          0: {
            items: 1,
            edgePadding: 90,
          },
          480: {
            items: 2,
            edgePadding: 50,
          },
          640: {
            edgePadding: 0,
            items: 3,
          },
          840: {
            items: 4,
          },
          1024: {
            items: 6,
          },
        },
      });
    }

    // ======= Input Placeholder

    // $('.field:not(.choice) input').each(function () {
    //   var inputValue = $(this).val();
    //   if (inputValue !== '') {
    //     $(this).parents('.field').addClass('focused');
    //   }
    // });

    // $('.field:not(.choice) input').focus(function () {
    //   $(this).parents('.field').addClass('focused');
    // });

    // $('.field:not(.choice) input').blur(function () {
    //   var inputValue = $(this).val();
    //   if (inputValue == '') {
    //     $(this).parents('.field').removeClass('focused');
    //   }
    // });
  });
});
