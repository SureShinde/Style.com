var config = {
  deps: ['js/custom'],
  paths: {
    tinyslider: 'js/lib/tiny-slider',
  },
};
