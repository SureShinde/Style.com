require(['jquery', 'tinyslider'], function ($) {
  $(document).ready(function () {
    // ======= Reviews Slider Home Page
    var reviewSlides = $('.reviews-slideshow .review-slide').length;
    if (reviewSlides > 0) {
      var slider = tns({
        container: '.reviews-slideshow',
        items: 1,
        mouseDrag: true,
        loop: true,
        responsive: {
          0: {
            items: 1,
            nav: true,
            controls: false,
          },
          640: {
            nav: false,
            controls: true,
          },
        },
      });
    }

    // ======= Mobile Menu
    $('.nav-toggle').on('click', function () {
      $('.navigation-holder').addClass('opened-menu');
    });
    $('.close-mobile-menu-button').on('click', function () {
      $(this).parents('.navigation-holder').removeClass('opened-menu');
    });

    // ======= Slideshow Stylist Page
    var worksSlides = $(
      '.wk-mp-profile-works-slideshow .wk-mp-profile-works-slide'
    ).length;
    if (worksSlides > 0) {
      var sliderWorks = tns({
        container: '.wk-mp-profile-works-slideshow',
        items: 4,
        nav: false,
        mouseDrag: true,
        controls: true,
        edgePadding: 100,
      });
    }

    var expertiseSlides = $(
      '.wk-mp-profile-expertise-slideshow .wk-mp-profile-expertise-slide'
    ).length;
    if (expertiseSlides > 0) {
      var sliderWorks = tns({
        container: '.wk-mp-profile-expertise-slideshow',
        items: 6,
        nav: false,
        mouseDrag: true,
        controls: true,
        gutter: 30,
      });
    }

    // ======= Input Placeholder

    // $('.field:not(.choice) input').each(function () {
    //   var inputValue = $(this).val();
    //   if (inputValue !== '') {
    //     $(this).parents('.field').addClass('focused');
    //   }
    // });

    // $('.field:not(.choice) input').focus(function () {
    //   $(this).parents('.field').addClass('focused');
    // });

    // $('.field:not(.choice) input').blur(function () {
    //   var inputValue = $(this).val();
    //   if (inputValue == '') {
    //     $(this).parents('.field').removeClass('focused');
    //   }
    // });
  });
});
