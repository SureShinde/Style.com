var config = {
    config: {
        mixins: {
            'mage/validation': {
                'Amasty_GiftCard/js/validation-email': true
            },
            'Magento_Ui/js/form/components/tab_group': {
                'Amasty_GiftCard/js/form/components/tab_group': true
            }
        }
    }
}
